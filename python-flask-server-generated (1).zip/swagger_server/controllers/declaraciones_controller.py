import connexion
import six

from swagger_server.models.req_declaraciones import ReqDeclaraciones  # noqa: E501
from swagger_server.models.res_declaraciones import ResDeclaraciones  # noqa: E501
from swagger_server.models.res_error import ResError  # noqa: E501
from swagger_server import util


def post_declaraciones(body):  # noqa: E501
    """Muestra las declaraciones de los servidores públicos permitiendo búsquedas avanzadas

     # noqa: E501

    :param body: JSON para peticiones de búsqueda avanzada
    :type body: dict | bytes

    :rtype: ResDeclaraciones
    """
    if connexion.request.is_json:
        body = ReqDeclaraciones.from_dict(connexion.request.get_json())  # noqa: E501
    return 'do some magic!'
