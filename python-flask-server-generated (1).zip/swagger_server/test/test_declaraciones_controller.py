# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.req_declaraciones import ReqDeclaraciones  # noqa: E501
from swagger_server.models.res_declaraciones import ResDeclaraciones  # noqa: E501
from swagger_server.models.res_error import ResError  # noqa: E501
from swagger_server.test import BaseTestCase


class TestDeclaracionesController(BaseTestCase):
    """DeclaracionesController integration test stubs"""

    def test_post_declaraciones(self):
        """Test case for post_declaraciones

        Muestra las declaraciones de los servidores públicos permitiendo búsquedas avanzadas
        """
        body = ReqDeclaraciones()
        response = self.client.open(
            '/v2/declaraciones',
            method='POST',
            data=json.dumps(body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
